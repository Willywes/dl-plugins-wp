<?php

$SIDEBARS = [
    'sidebar-1' => 'Sidebar 1',
    'sidebar-2' => 'Sidebar 2',
    'sidebar-3' => 'Sidebar 3',
];


